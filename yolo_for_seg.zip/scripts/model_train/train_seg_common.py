
from __future__ import annotations

import argparse
import os
import random
import shutil
import time
from pathlib import Path

import numpy as np
import torch
import yaml

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

from ultralytics import YOLO



REPO_ROOT = Path(__file__).resolve().parents[2]


def resolve_input_path(path: Path) -> Path:
    if path.is_absolute():
        return path.resolve()
    return (REPO_ROOT / path).resolve()

def resolve_output_path(path: Path) -> Path:
    if path.is_absolute():
        return path.resolve()
    return (REPO_ROOT / path).resolve()

def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

def prepare_resolved_data_yaml(
    source_yaml: Path,
    output_project: Path,
) -> Path:
    if not source_yaml.is_file():
        raise FileNotFoundError(
            f"数据配置文件不存在：{source_yaml}"
        )

    with source_yaml.open("r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    if not isinstance(config, dict):
        raise ValueError("data.yaml 内容格式不正确。")

    configured_root = config.get("path")

    if configured_root:
        configured_root = Path(str(configured_root))

        if configured_root.is_absolute():
            dataset_root = configured_root.resolve()
        else:
            dataset_root = (REPO_ROOT / configured_root).resolve()
    else:
        dataset_root = source_yaml.parent.resolve()

    if not dataset_root.is_dir():
        raise FileNotFoundError(
            f"数据集根目录不存在：{dataset_root}"
        )

    resolved_config = dict(config)
    resolved_config["path"] = str(dataset_root)

    for split in ("train", "val", "test"):
        split_path = config.get(split)

        if split_path is None:
            if split in ("train", "val"):
                raise ValueError(
                    f"data.yaml 缺少必要配置：{split}"
                )
            continue

        paths = (
            split_path
            if isinstance(split_path, list)
            else [split_path]
        )

        for item in paths:
            p = Path(str(item))

            if p.is_absolute():
                resolved = p
            else:
                resolved = dataset_root / p

            if not resolved.exists():
                raise FileNotFoundError(
                    f"{split} 数据路径不存在：{resolved}"
                )

    resolved_dir = output_project / "_resolved_data"
    resolved_dir.mkdir(parents=True, exist_ok=True)

    resolved_yaml = resolved_dir / "data_resolved.yaml"

    with resolved_yaml.open("w", encoding="utf-8") as f:
        yaml.safe_dump(
            resolved_config,
            f,
            allow_unicode=True,
            sort_keys=False,
        )

    return resolved_yaml

# 主训练流程

def main() -> None:
    parser = argparse.ArgumentParser(
        description="统一训练 YOLO 实例分割模型。"
    )

    parser.add_argument(
        "--data",
        type=Path,
        default=Path(
            "data/processed/yolo_merged_noaug/data.yaml"
        ),
        help="数据集 data.yaml 路径。",
    )

    parser.add_argument(
        "--model",
        type=str,
        default="yolo11n-seg.pt",
        help="模型权重文件或 Ultralytics 官方模型名称。",
    )

    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--device", type=str, default="0")
    parser.add_argument("--workers", type=int, default=2)

    parser.add_argument(
        "--project",
        type=Path,
        default=Path("outputs/seg_runs"),
        help="实验结果保存目录。",
    )

    parser.add_argument(
        "--name",
        type=str,
        default="merged_noaug_yolo11n_seg",
        help="本次实验名称。",
    )

    parser.add_argument("--patience", type=int, default=50)
    parser.add_argument("--close-mosaic", type=int, default=10)

    parser.add_argument("--seed", type=int, default=0)

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="仅检查配置，不启动训练。",
    )

    args = parser.parse_args()

    data_path = resolve_input_path(args.data)
    project_path = resolve_output_path(args.project)

    if not data_path.is_file():
        raise FileNotFoundError(
            f"找不到数据配置文件：{data_path}"
        )

    if args.epochs <= 0 or args.imgsz <= 0:
        raise ValueError("epochs 和 imgsz 必须大于 0。")

    if args.batch <= 0 or args.workers < 0:
        raise ValueError(
            "batch 必须大于 0，workers 不能小于 0。"
        )

    if args.close_mosaic < 0:
        raise ValueError("close-mosaic 不能小于 0。")

    project_path.mkdir(parents=True, exist_ok=True)

    resolved_data = prepare_resolved_data_yaml(
        data_path,
        project_path,
    )

    model_path = Path(args.model)

    if model_path.is_absolute():
        checkpoint = model_path
    else:
        project_checkpoint = REPO_ROOT / model_path

        if project_checkpoint.is_file():
            checkpoint = project_checkpoint.resolve()
        else:
            checkpoint = args.model

    # 实验配置
    train_kwargs = {
        "data": str(resolved_data),
        "epochs": args.epochs,
        "imgsz": args.imgsz,
        "batch": args.batch,
        "device": args.device,
        "workers": args.workers,
        "project": str(project_path),
        "name": args.name,
        "patience": args.patience,
        "close_mosaic": args.close_mosaic,
        "task": "segment",
        "pretrained": True,
        "optimizer": "AdamW",
        "lr0": 0.001,
        "cos_lr": True,
        "seed": args.seed,
        "deterministic": True,
        "amp": True,
        "weight_decay": 0.0005,
        "warmup_epochs": 3.0,
        "warmup_momentum": 0.8,
        "warmup_bias_lr": 0.1,
        "lrf": 0.01,
        "mosaic": 1.0,
        "mixup": 0.0,
        "copy_paste": 0.0,
        "fliplr": 0.5,
        "translate": 0.1,
        "scale": 0.5,
    }

    print("=" * 72)
    print("统一 YOLO 实例分割训练")
    print("=" * 72)
    print(f"项目根目录 : {REPO_ROOT}")
    print(f"原始数据配置: {data_path}")
    print(f"实际数据配置: {resolved_data}")
    print(f"模型权重   : {checkpoint}")
    print(f"实验输出目录: {project_path}")
    print(f"实验名称   : {args.name}")
    print("-" * 72)

    for key, value in train_kwargs.items():
        print(f"{key:16s}: {value}")

    if args.dry_run:
        print("-" * 72)
        print("Dry-run 检查通过：尚未开始训练。")
        return

    if args.device != "cpu":
        if not torch.cuda.is_available():
            raise RuntimeError(
                "当前 PyTorch 无法使用 CUDA。"
                "请先检查当前解释器和 GPU 环境。"
            )

        print("-" * 72)
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(
            f"PyTorch CUDA: {torch.version.cuda}"
        )

    set_seed(args.seed)

    print("-" * 72)
    print("开始加载模型……")

    model = YOLO(str(checkpoint))

    print("模型加载完成，开始训练……")
    start_time = time.perf_counter()

    results = model.train(**train_kwargs)

    elapsed = time.perf_counter() - start_time

    print("=" * 72)
    print("训练完成")
    print(f"结果目录: {results.save_dir}")
    print(f"训练耗时: {elapsed / 60:.2f} 分钟")
    print("=" * 72)


if __name__ == "__main__":
    main()
